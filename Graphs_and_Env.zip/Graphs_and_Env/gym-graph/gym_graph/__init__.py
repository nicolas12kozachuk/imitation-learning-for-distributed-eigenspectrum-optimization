from gymnasium.envs.registration import register

register(
    id='gym_graph/GraphEnv',
    entry_point='gym_graph.envs:GraphEnv',
)