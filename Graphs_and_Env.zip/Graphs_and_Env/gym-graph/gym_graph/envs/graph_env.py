import math
from networkx.algorithms import dag
import numpy as np
import gymnasium as gym
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.cm
import dgl
import networkx as nx
import matplotlib.cm
import random
from gymnasium import error, spaces, utils
from gymnasium.utils import seeding
from numpy import e, linalg as LA
import matplotlib.colors as colors
import matplotlib.cm as cmx
from matplotlib.cm import ScalarMappable

# define class for custom enviroment
class GraphEnv(gym.Env):
  metadata = {'render.modes': ['human']}

  # function to assign edge array with corresponding weights
  def assign_edges(self,nodes):
    edges = np.zeros(self.num_edges)
    counter = 0
    for i in range(len(nodes[:,0])):
      for j in range(i+1,len(nodes[:,0])):
        if(nodes[i,j] > 0):
          edges[counter] = nodes[i,j]
        else:
          edges[counter] = nodes[i,j]
        counter = counter + 1
    return edges

  # enviroment initialization 
  def __init__(self,nodes):
    super(GraphEnv, self).__init__()
    self.num_nodes = len(nodes[:,0])
    self.num_edges = int((self.num_nodes*(self.num_nodes-1))/2)
    self.nodes = nodes
    self.edges = self.assign_edges(nodes) 
    self.initial_nodes = nodes
    self.initial_edges = self.edges

    # calculate bounds of domain for possible edge manipulations
    low = 0.1 - self.edges
    high = (2*self.num_edges - 0.1*2*(self.num_edges-1))*np.ones(self.num_edges) - self.edges

    highest_possible_edge_weight = 2*self.num_edges - 0.1*2*(self.num_edges-1)
    
    # set action and observation(state) spaces
    self.action_space = spaces.Box(low=low, high=high, shape=np.array([self.num_edges]), dtype=np.float64)
    self.observation_space = spaces.Box(low=0.1, high=highest_possible_edge_weight , shape=np.array([self.num_edges]), dtype=np.float64)

  # function to construct laplacian matrix
  def construct_lap(self):
    lap = np.zeros((self.num_nodes,self.num_nodes))
    counter = 0
    for i in range(len(self.nodes[:,0])):
      for j in range(i+1,len(self.nodes[:,0])):
        if(self.nodes[i,j] > 0):
          lap[i,j] = -self.edges[counter]
          lap[j,i] = -self.edges[counter]
          lap[i,i] = lap[i,i] + self.edges[counter]
          lap[j,j] = lap[j,j] + self.edges[counter]
          counter = counter + 1
    return lap

  # function to get reward(which is objective function value)
  def get_reward(self):
    L = self.construct_lap()
    nVertices = len(L[:,0])
    L = L + 0.1*np.identity(nVertices)
    eigenvalues, eigenvectors = LA.eig(L)
    ev = np.sort(eigenvalues)

    gamma = 0.001
    h = 0.1

    value = 0
    for i in range(len(ev)):
        lambda_i = ev[i]
        for j in range(len(ev)):
            lambda_j = ev[j]
            value += ((h*(h**2+lambda_j)+h*lambda_i) / (gamma*nVertices*lambda_j*(lambda_i**2+2*lambda_i*(h**2-lambda_j)+(h**2+lambda_j)**2)))

    value /= nVertices
    
    return abs(value)
  
  # function to return observation
  def _get_obs(self):
    return self.edges

  # function to return edge info
  def _get_info(self):
    return {"edges": self.edges}

  # function to perform step
  def step(self, action: np.ndarray,):
    # perform action
    action = np.float64(action)
    self.edges = np.float64(self.edges + action)

    # normalize weights
    edge_sum = 0
    for i in range(self.num_edges):
      edge_sum = edge_sum + self.edges[i]

    norm_ratio = self.num_edges / edge_sum

    for i in range(self.num_edges):
      self.edges[i] = np.float64(self.edges[i] * norm_ratio)

    # reassign values for node array 
    counter = 0
    for i in range(len(self.nodes[:,0])):
      for j in range(i+1,len(self.nodes[:,0])):
        if(self.nodes[i,j] > 0):
          self.nodes[i,j] = self.edges[counter]
          self.nodes[j,i] = self.edges[counter]
          counter = counter + 1

    # get reward
    reward = self.get_reward()

    observation = self._get_obs()
    info = self._get_info()
    return observation, reward, True, True, info
  
  # function to reset state values
  def reset(self, seed=None):
    super(GraphEnv, self).__init__()

    # reset node array values
    self.new_nodes = np.zeros((self.num_nodes,self.num_nodes))
    for i in range(self.num_nodes):
      for j in range(self.num_nodes):
        if(i != j):
          self.new_nodes[i,j] = 1

    self.nodes = self.initial_nodes # self.new_nodes

    # reset edge weight values
    self.edges = self.initial_edges#np.ones(self.num_edges) 

    observation = self._get_obs()
    info = self._get_info()

    return observation, info

  # helper function for displaying graph
  def numpy_to_graph(self, A,type_graph='dgl',node_features=None):
      G = nx.from_numpy_array(A)

      if node_features != None:
          for n in G.nodes():
              for k,v in node_features.items():
                  G.nodes[n][k] = v[n]

      if type_graph == 'nx':
          return G

      G = G.to_directed()

      if node_features != None:
          node_attrs = list(node_features.keys())
      else:
          node_attrs = []

      g = dgl.from_networkx(G, node_attrs=node_attrs, edge_attrs=['weight'])
      return g
  
  # function to display graph
  def render(self, mode='human', close=False):
    G = self.numpy_to_graph(self.nodes,type_graph='nx')

    pos=nx.circular_layout(G)
    
    jet = cm = plt.get_cmap('Greys') 
    cNorm  = colors.Normalize(vmin=0, vmax=np.max(self.edges))
    sm = cmx.ScalarMappable(norm=cNorm, cmap=jet)
    colorList = []

    for i in range(self.num_edges):
      colorVal = sm.to_rgba(self.edges[i])
      colorList.append(colorVal)

    nx.draw_networkx(G,pos,edge_color=colorList)
    plt.colorbar(sm)
    plt.show()